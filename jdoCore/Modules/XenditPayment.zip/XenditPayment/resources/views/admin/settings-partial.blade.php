{{-- Xendit Payment Gateway Settings --}}
{{-- This partial is included in admin settings when the XenditPayment module is active --}}
<div class="card" style="border:none;border-radius:12px">
    <div class="card-body">
        <div class="d-flex align-items-center mb-3">
            <h6 class="fw-semibold mb-0"><i class="bi bi-credit-card-2-front me-2"></i>Xendit Payment Gateway</h6>
            <span class="badge bg-primary ms-2 small">Module</span>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-medium">Mode</label>
            <select name="xendit_mode" class="form-select">
                <option value="sandbox" {{ ($settings['payment']['xendit_mode'] ?? 'sandbox') === 'sandbox' ? 'selected' : '' }}>Sandbox (Testing)</option>
                <option value="live" {{ ($settings['payment']['xendit_mode'] ?? '') === 'live' ? 'selected' : '' }}>Live
                    (Produksi)</option>
            </select>
            <input type="hidden" name="_group[xendit_mode]" value="payment">
            <input type="hidden" name="_type[xendit_mode]" value="string">
            <small class="text-muted">Gunakan mode Sandbox untuk testing. Gunakan API key sesuai mode yang
                dipilih.</small>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-medium">Secret API Key <span class="text-danger">*</span></label>
            <input type="password" name="xendit_secret_key" class="form-control"
                value="{{ config('app.demo_mode') ? 'hidden_in_demo_mode' : ($settings['payment']['xendit_secret_key'] ?? '') }}"
                placeholder="xnd_development_... atau xnd_production_...">
            <input type="hidden" name="_group[xendit_secret_key]" value="payment">
            <input type="hidden" name="_type[xendit_secret_key]" value="string">
            <small class="text-muted">Dapatkan di <a href="https://dashboard.xendit.co/settings/developers#api-keys"
                    target="_blank" class="fw-semibold">Xendit Dashboard > API Keys</a></small>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-medium">Callback Verification Token <span
                    class="text-danger">*</span></label>
            <input type="password" name="xendit_callback_token" class="form-control"
                value="{{ config('app.demo_mode') ? 'hidden_in_demo_mode' : ($settings['payment']['xendit_callback_token'] ?? '') }}"
                placeholder="Token verifikasi callback Xendit">
            <input type="hidden" name="_group[xendit_callback_token]" value="payment">
            <input type="hidden" name="_type[xendit_callback_token]" value="string">
            <small class="text-muted">Dapatkan di <a href="https://dashboard.xendit.co/settings/developers#callbacks"
                    target="_blank" class="fw-semibold">Xendit Dashboard > Callbacks</a>. Set webhook URL ke:
                <code>{{ url('/api/payment/xendit/callback') }}</code></small>
        </div>

        <hr>
        <div class="mb-3">
            <label class="form-label small fw-medium">Channel Pembayaran Aktif</label>
            @php
                $xenditEnabledRaw = $settings['payment']['xendit_enabled_channels'] ?? '[]';
                $xenditEnabled = is_string($xenditEnabledRaw) ? json_decode($xenditEnabledRaw, true) : $xenditEnabledRaw;
                if (!is_array($xenditEnabled))
                    $xenditEnabled = [];

                $channelGroups = [
                    'Virtual Account' => [
                        'BCA' => 'BCA',
                        'BNI' => 'BNI',
                        'BRI' => 'BRI',
                        'MANDIRI' => 'Mandiri',
                        'PERMATA' => 'Permata',
                        'BSI' => 'BSI',
                        'CIMB' => 'CIMB',
                    ],
                    'E-Wallet' => [
                        'OVO' => 'OVO',
                        'DANA' => 'DANA',
                        'SHOPEEPAY' => 'ShopeePay',
                        'LINKAJA' => 'LinkAja',
                        'ASTRAPAY' => 'AstraPay',
                        'JENIUSPAY' => 'Jenius Pay',
                    ],
                    'QRIS' => ['QRIS' => 'QRIS (Semua E-Wallet)'],
                    'Retail Outlet' => ['ALFAMART' => 'Alfamart', 'INDOMARET' => 'Indomaret'],
                ];
            @endphp

            @foreach($channelGroups as $groupLabel => $channels)
                <div class="mb-2">
                    <div class="small fw-bold text-muted text-uppercase mb-1"
                        style="font-size:0.7rem; letter-spacing: 0.5px;">{{ $groupLabel }}</div>
                    <div class="d-flex flex-wrap gap-2">
                        @foreach($channels as $code => $label)
                            <div class="form-check">
                                <input type="checkbox" name="xendit_channels_list[]" value="{{ $code }}"
                                    class="form-check-input" {{ in_array($code, $xenditEnabled) ? 'checked' : '' }}>
                                <label class="form-check-label small">{{ $label }}</label>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endforeach

            <input type="hidden" name="_group[xendit_enabled_channels]" value="payment">
            <input type="hidden" name="_type[xendit_enabled_channels]" value="json">
        </div>
    </div>
</div>